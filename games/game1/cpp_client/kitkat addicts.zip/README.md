# Steps to Compile on CIMS:

Run the following commands:  
```module load gcc-9.2```  
```g++ client.cpp -o client```  
```./client```  
  
Note that we assume that number of stones are <= 200 and k <= 15 and input player numbers in {1, 2}